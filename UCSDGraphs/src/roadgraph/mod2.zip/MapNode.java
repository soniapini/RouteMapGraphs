package roadgraph;

import java.util.LinkedList;
import java.util.List;

import geography.GeographicPoint;

/** @author Sonia Pini
 *  a class which represents a node inside the graph
 */
public class MapNode {
	private GeographicPoint location;
	private List<MapEdge> edges;
	
	/** 
	 * Create a new MapNode with outgoing edges 
	 */
	public MapNode(GeographicPoint location, List<MapEdge> edges) {
		super();
		this.location = location;
		this.edges = edges;
	}
	
	/** 
	 * Create a new MapNode without outgoing edges 
	 */
	public MapNode(GeographicPoint location) {
		super();
		this.location = location;
		edges = new LinkedList<>();
	}

	/**
	 * Get the geographic location of a MapNode 
	 * @return The MapNode as GeographicPoints
	 */
	public GeographicPoint getLocation() {
		return location;
	}

	/**
	 * Get the outgoing edges from the node
	 * @return the outgoing edges from the node as MapEdge
	 */
	public List<MapEdge> getEdges() {
		return edges;
	}
	
	/**
	 * Get the number of outgoing edges from the node
	 * @return The number of outgoing edges from the node.
	 */
	public int getNumberOfEdges() {
		return edges.size();
	}

	/**
	 * Add a new outgoing edge from the node
	 * @param edge the outgoing edge to be added to the node
	 */
	public void addEdge(MapEdge edge) {
		edges.add(edge);
	}
	
	/**
	 * Add a set of new outgoing edge from the node
	 * @param edges the outgoing edges to be added to the node
	 */
	public void addEdges(List<MapEdge> edges) {
		this.edges.addAll(edges);
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((edges == null) ? 0 : edges.hashCode());
		result = prime * result + ((location == null) ? 0 : location.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MapNode other = (MapNode) obj;
		if (edges == null) {
			if (other.edges != null)
				return false;
		} else if (!edges.equals(other.edges))
			return false;
		if (location == null) {
			if (other.location != null)
				return false;
		} else if (!location.equals(other.location))
			return false;
		return true;
	}
	
}
