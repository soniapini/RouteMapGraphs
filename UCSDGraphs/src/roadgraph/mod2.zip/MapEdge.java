package roadgraph;

/** @author Sonia Pini
 *  a class which represents a edge between nodes graph
 *  node graph are geographic location
 */
public class MapEdge {
	private MapNode startNode;
	private MapNode endNode;
	private String streetName;
	// Length in km
	private double distance;
	private String streetType; //may be an Enum
	
	/** 
	 * Create a new MapEdge between two MapNode
	 */
	public MapEdge(MapNode startNode, MapNode endNode, 
			String streetName, double distance, String streetType) {
		super();
		this.startNode = startNode;
		this.endNode = endNode;
		this.streetName = streetName;
		this.distance = distance;
		this.streetType = streetType;
	}

	/**
	 * @return the start node of the edge
	 */
	public MapNode getStartNode() {
		return startNode;
	}
	
	/**
	 * 
	 * @return the end node of the edge
	 */
	public MapNode getEndNode() {
		return endNode;
	}

	/**
	 * 
	 * @return the street name associated with the edge
	 */
	public String getStreetName() {
		return streetName;
	}

	/**
	 * 
	 * @return the distance in Km assocaited with the edge
	 */
	public double getDistance() {
		return distance;
	}

	/**
	 * 
	 * @return the street type associated with the edge
	 */
	public String getStreetType() {
		return streetType;
	}

}
